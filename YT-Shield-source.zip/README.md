# YT-Shield

Android DNS filtering app using Android's local `VpnService` API.

## Build an APK

1. Upload this ZIP's contents into the root of `Brian12292010/YT-Shield` (not the ZIP file itself).
2. Commit the files to the `main` branch.
3. Open **Actions → Android APK**. The workflow also runs automatically on pushes to `main`.
4. Open the completed run and download the `YT-Shield-debug-apk` artifact.

## Features in this starter build

- On-device VPN-based DNS filtering (IPv4 UDP DNS).
- Built-in ad/tracker domain rules.
- Custom blocklist and allowlist; allowlist takes precedence.
- Basic query and blocked-query counters.
- GitHub Actions debug APK build.

## Important scope notes

This is a starter implementation, not a production-grade network filter. It filters DNS lookups, not HTTPS content. It does not decrypt traffic or proxy video streams. YouTube can serve ads from domains shared with video content, so DNS filtering cannot reliably remove ads inside the official YouTube app. IPv6 DNS and DNS-over-HTTPS/TLS paths are not filtered by this initial version.

The app asks Android for VPN permission. Non-blocked DNS queries are forwarded to Cloudflare DNS (1.1.1.1); other app traffic is not routed through a remote VPN server.
