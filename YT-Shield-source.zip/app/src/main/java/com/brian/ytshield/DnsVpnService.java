package com.brian.ytshield;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.VpnService;
import android.os.ParcelFileDescriptor;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public class DnsVpnService extends VpnService {
    private static final String ACTION_RELOAD = "com.brian.ytshield.RELOAD_RULES";
    private ParcelFileDescriptor tunnel;
    private volatile boolean running;
    private Thread thread;
    private final Set<String> blocked = new HashSet<>();
    private final Set<String> allowed = new HashSet<>();
    private SharedPreferences prefs;

    public static void reloadRules(android.content.Context context) {
        context.sendBroadcast(new Intent(ACTION_RELOAD).setPackage(context.getPackageName()));
    }

    @Override public void onCreate() {
        super.onCreate();
        prefs = getSharedPreferences("shield", MODE_PRIVATE);
        loadRules();
        registerReceiver(new android.content.BroadcastReceiver() {
            @Override public void onReceive(android.content.Context c, Intent i) { loadRules(); }
        }, new android.content.IntentFilter(ACTION_RELOAD));
    }

    private synchronized void loadRules() {
        blocked.clear();
        allowed.clear();
        addLines(blocked, "doubleclick.net\ngooglesyndication.com\ngoogleadservices.com\nadservice.google.com\npagead2.googlesyndication.com\nadnxs.com\nadform.net");
        addLines(blocked, prefs.getString("deny", ""));
        addLines(allowed, prefs.getString("allow", ""));
    }

    private void addLines(Set<String> target, String text) {
        for (String line : text.split("\\R")) {
            String d = line.trim().toLowerCase(Locale.ROOT);
            if (d.startsWith("||")) d = d.substring(2);
            if (d.startsWith(".")) d = d.substring(1);
            if (d.endsWith("^")) d = d.substring(0, d.length()-1);
            if (d.matches("[a-z0-9.-]+") && d.contains(".")) target.add(d);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (tunnel == null) establish();
        return START_STICKY;
    }

    private void establish() {
        try {
            tunnel = new Builder().setSession("YT Shield")
                .addAddress("10.10.10.2", 32)
                .addDnsServer("10.10.10.1")
                .addRoute("10.10.10.1", 32)
                .setMtu(1500).establish();
            if (tunnel == null) { stopSelf(); return; }
            running = true;
            thread = new Thread(this::runLoop, "YT-Shield-DNS");
            thread.start();
        } catch (Exception e) { stopSelf(); }
    }

    private void runLoop() {
        byte[] buf = new byte[32767];
        try (FileInputStream in = new FileInputStream(tunnel.getFileDescriptor());
             FileOutputStream out = new FileOutputStream(tunnel.getFileDescriptor())) {
            while (running) {
                int n = in.read(buf);
                if (n < 28) continue;
                int version = (buf[0] >> 4) & 15;
                if (version != 4 || (buf[9] & 255) != 17) continue; // IPv4 UDP DNS only
                int ipLen = (buf[0] & 15) * 4;
                int dstPort = u16(buf, ipLen + 2);
                if (dstPort != 53 || ipLen + 8 > n) continue;
                int udpLen = u16(buf, ipLen + 4);
                if (udpLen < 20 || ipLen + udpLen > n) continue;
                int dnsOff = ipLen + 8;
                String domain = readQName(buf, dnsOff + 12, dnsOff + udpLen);
                if (domain == null) continue;

                prefs.edit().putLong("queries", prefs.getLong("queries", 0) + 1).apply();
                byte[] dnsReply;
                if (isBlocked(domain)) {
                    dnsReply = nxdomain(buf, dnsOff, udpLen);
                    prefs.edit().putLong("blocked", prefs.getLong("blocked", 0) + 1).apply();
                } else {
                    dnsReply = queryUpstream(buf, dnsOff, udpLen);
                    if (dnsReply == null) continue;
                }
                byte[] reply = makeReply(buf, ipLen, dnsReply);
                out.write(reply);
            }
        } catch (Exception ignored) { }
    }

    private synchronized boolean isBlocked(String host) {
        for (String d : allowed) if (host.equals(d) || host.endsWith("." + d)) return false;
        for (String d : blocked) if (host.equals(d) || host.endsWith("." + d)) return true;
        return false;
    }

    private String readQName(byte[] b, int p, int end) {
        try {
            StringBuilder out = new StringBuilder();
            int pos = p;
            while (pos < end) {
                int len = b[pos++] & 255;
                if (len == 0) break;
                if ((len & 0xC0) != 0 || pos + len > end) return null;
                if (out.length() > 0) out.append('.');
                out.append(new String(b, pos, len, StandardCharsets.US_ASCII));
                pos += len;
            }
            return out.length() == 0 ? null : out.toString().toLowerCase(Locale.ROOT);
        } catch (Exception e) { return null; }
    }

    private byte[] nxdomain(byte[] packet, int off, int len) {
        byte[] r = Arrays.copyOfRange(packet, off, off + len);
        r[2] = (byte)0x81;
        r[3] = (byte)0x83; // response + NXDOMAIN
        r[6]=r[7]=r[8]=r[9]=0;
        return r;
    }

    private byte[] queryUpstream(byte[] packet, int off, int len) {
        try {
            DatagramSocket socket = new DatagramSocket();
            if (!protect(socket)) { socket.close(); return null; }
            socket.setSoTimeout(2500);
            byte[] query = Arrays.copyOfRange(packet, off, off + len);
            InetAddress dns = InetAddress.getByName("1.1.1.1");
            socket.send(new DatagramPacket(query, query.length, dns, 53));
            byte[] data = new byte[4096];
            DatagramPacket response = new DatagramPacket(data, data.length);
            socket.receive(response);
            socket.close();
            return Arrays.copyOf(data, response.getLength());
        } catch (Exception e) { return null; }
    }

    private byte[] makeReply(byte[] request, int ipLen, byte[] dns) {
        int total = 20 + 8 + dns.length;
        byte[] r = new byte[total];
        r[0] = 0x45; r[1] = request[1];
        r[2] = (byte)(total >> 8); r[3] = (byte)total;
        r[6] = 0x40; r[8] = 64; r[9] = 17;
        System.arraycopy(request, 16, r, 12, 4); // source = original destination
        System.arraycopy(request, 12, r, 16, 4); // destination = original source
        int sourcePort = u16(request, ipLen + 2);
        int destPort = u16(request, ipLen);
        put16(r, 20, 53); put16(r, 22, sourcePort);
        put16(r, 24, 8 + dns.length);
        System.arraycopy(dns, 0, r, 28, dns.length);
        put16(r, 10, checksum(r, 0, 20));
        // UDP checksum 0 is valid for IPv4.
        return r;
    }

    private int u16(byte[] b, int p) { return ((b[p]&255)<<8) | (b[p+1]&255); }
    private void put16(byte[] b, int p, int v) { b[p]=(byte)(v>>8); b[p+1]=(byte)v; }
    private int checksum(byte[] b, int off, int len) {
        long sum=0;
        for (int i=off; i<off+len; i+=2)
            sum += ((b[i]&255)<<8) | (i+1<off+len ? (b[i+1]&255) : 0);
        while ((sum >> 16) != 0) sum=(sum&0xffff)+(sum>>16);
        return (int)(~sum)&0xffff;
    }

    @Override public void onDestroy() {
        running = false;
        try { if (tunnel != null) tunnel.close(); } catch (Exception ignored) { }
        tunnel = null;
        super.onDestroy();
    }
}
