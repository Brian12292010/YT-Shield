package com.brian.ytshield;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.VpnService;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int VPN_REQUEST = 42;
    private SharedPreferences prefs;
    private TextView state, stats;

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        prefs = getSharedPreferences("shield", MODE_PRIVATE);
        buildUi();
        refresh();
    }

    private void buildUi() {
        int pad = (int)(20 * getResources().getDisplayMetrics().density);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("YT Shield");
        title.setTextSize(30);
        page.addView(title);

        state = new TextView(this);
        state.setTextSize(16);
        state.setPadding(0, pad, 0, pad / 2);
        page.addView(state);

        Button on = new Button(this);
        on.setText("啟用 DNS 防護");
        on.setOnClickListener(v -> {
            Intent prepare = VpnService.prepare(this);
            if (prepare != null) startActivityForResult(prepare, VPN_REQUEST);
            else startService(new Intent(this, DnsVpnService.class));
        });
        page.addView(on);

        Button off = new Button(this);
        off.setText("停止防護");
        off.setOnClickListener(v -> {
            stopService(new Intent(this, DnsVpnService.class));
            state.setText("防護已停止");
        });
        page.addView(off);

        stats = new TextView(this);
        stats.setPadding(0, pad, 0, pad);
        page.addView(stats);

        TextView denyLabel = new TextView(this);
        denyLabel.setText("自訂封鎖網域（每行一個，例如 ads.example.com）");
        page.addView(denyLabel);
        EditText deny = new EditText(this);
        deny.setMinLines(3);
        deny.setGravity( topGravity() );
        deny.setText(prefs.getString("deny", ""));
        page.addView(deny, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        Button saveDeny = new Button(this);
        saveDeny.setText("儲存封鎖清單");
        saveDeny.setOnClickListener(v -> {
            prefs.edit().putString("deny", deny.getText().toString()).apply();
            DnsVpnService.reloadRules(this);
            refresh();
        });
        page.addView(saveDeny);

        TextView allowLabel = new TextView(this);
        allowLabel.setText("白名單（每行一個；允許網域優先）");
        allowLabel.setPadding(0, pad, 0, 0);
        page.addView(allowLabel);
        EditText allow = new EditText(this);
        allow.setMinLines(3);
        allow.setGravity(topGravity());
        allow.setText(prefs.getString("allow", ""));
        page.addView(allow);
        Button saveAllow = new Button(this);
        saveAllow.setText("儲存白名單");
        saveAllow.setOnClickListener(v -> {
            prefs.edit().putString("allow", allow.getText().toString()).apply();
            DnsVpnService.reloadRules(this);
            refresh();
        });
        page.addView(saveAllow);

        Button resetStats = new Button(this);
        resetStats.setText("重設統計");
        resetStats.setOnClickListener(v -> {
            prefs.edit().putLong("queries", 0).putLong("blocked", 0).apply();
            refresh();
        });
        page.addView(resetStats);

        TextView disclaimer = new TextView(this);
        disclaimer.setText("\n說明：此版本以本機 VPN 攔截 DNS 網域，不解密 HTTPS，也不會把流量送往第三方 VPN。DNS 過濾無法可靠移除官方 YouTube App 中與影片同網域提供的廣告。");
        disclaimer.setTextSize(13);
        page.addView(disclaimer);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(page);
        setContentView(scroll);
    }

    private int topGravity() { return android.view.Gravity.TOP; }

    private void refresh() {
        state.setText("DNS 過濾器 · 使用者可自行啟用或停止 VPN 權限");
        stats.setText("DNS 查詢：" + prefs.getLong("queries", 0)
            + "\n已封鎖：" + prefs.getLong("blocked", 0));
    }

    @Override protected void onResume() {
        super.onResume();
        if (prefs != null && stats != null) refresh();
    }

    @Override protected void onActivityResult(int request, int result, Intent data) {
        super.onActivityResult(request, result, data);
        if (request == VPN_REQUEST && result == RESULT_OK) {
            startService(new Intent(this, DnsVpnService.class));
            state.setText("DNS 防護啟動中");
        }
    }
}
