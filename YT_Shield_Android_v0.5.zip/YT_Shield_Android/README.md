# YT Shield — Android DNS Filter Prototype v0.5

## v0.5 本階段新增
- 可列出手機上有啟動圖示的 App，直接多選要排除過濾的 App，不必手動查套件名稱。
- DNS 上游增加 Cloudflare 與 Google Public DNS 備援；回應會檢查交易 ID 與 DNS response 標記。
- 版本號升級至 0.5.0。

## v0.4 既有功能
- WorkManager 每 24 小時自動更新規則（需網路連線）。
- 手動與背景更新共用同一套清單下載器。
- 更新前驗證清單至少 1,000 個有效網域，避免錯誤或不完整下載覆蓋舊規則。
- VPN 運作中也會讀取最新封鎖清單，更新後不必重啟 VPN。
- 可手動下載 StevenBlack hosts 清單（HTTPS）並解析成網域封鎖規則。
- 更新失敗時保留上次成功下載的規則。
- 遠端規則網域數量與最後更新時間。
- 網域白名單。
- 以 Android VPN Builder 的 disallowed-app 清單設定 App 例外（輸入 Android 套件名稱）。
- 本機 DNS 攔截 / 放行計數。

## 重要限制
- 本專案仍是工程原型，未經 Android Studio 編譯、靜態分析或真機測試，不應視為正式安全產品。
- 過濾僅限經過本機 VPN 的明文 UDP DNS；TCP DNS、DoH、DoT、部分 App 私有 DNS、VPN 衝突與其他加密流量可能繞過。
- Android App 例外使用套件名稱；若套件名稱錯誤，設定可能不生效。套用例外需停止並重新啟動 VPN。
- hosts 清單可能造成誤攔截；白名單可解除網域封鎖。原型最多保存 40,000 個遠端網域，建議先小範圍測試。
- YouTube 的廣告與影片可能共用網域，DNS 無法可靠區分；不能承諾移除所有影片廣告。
- 此原型尚無自動排程更新、規則簽章驗證、分類訂閱、流量逐筆紀錄、IPv6 extension header、TCP DNS 或完整斷線恢復。
- 未編譯 APK。請以 Android Studio + JDK 17 開啟專案、Gradle Sync，再部署到測試機。

## 隱私與資料流
- 不建立帳號、不收集或上傳瀏覽紀錄。
- 點選更新時，App 會向 `raw.githubusercontent.com/StevenBlack/hosts` 下載 hosts 清單。
- 未封鎖的 DNS 查詢會送往 Cloudflare DNS `1.1.1.1`；DNS 服務商仍可看到查詢網域。
- 白名單、規則清單與統計保存在裝置本機 SharedPreferences。

## 下一階段：雲端自動產生 APK
專案已加入 GitHub Actions 工作流程：`.github/workflows/android-apk.yml`。
將整個專案推送到 GitHub 的 `main` 或 `master` 分支後，或在 Actions 頁面手動執行 **Build YT Shield APK**，雲端會安裝 JDK 17、Android SDK 35 與 Gradle 8.9，並執行 `:app:assembleDebug`。成功後可在該次工作流程的 Artifacts 下載 `YT-Shield-debug-APK`，裡面是可側載測試的 `app-debug.apk`。

注意：這是未簽署的 debug 測試 APK，不是可上架 Google Play 的正式 release APK。正式版仍需建立並安全保管簽署金鑰，並完成真機相容性、VPN 斷線恢復、DNS 封包與耗電測試。此工作流程尚未在本環境執行，不能宣稱 APK 已成功建置。v0.4 新增 WorkManager 依賴，第一次開啟 App 後會排程每日更新；Android WorkManager 的週期工作不是精準鬧鐘，實際執行時間由系統電量與背景限制決定。


## v0.5 測試注意
- App 選擇器只列出有 Launcher 圖示的 App；系統服務與沒有啟動圖示的套件不會出現在清單。
- DNS 備援只在第一個上游逾時或回應格式不符時切換；未加密 DNS 仍可能被網路環境限制。
- 尚未加入 DNS-over-TCP、DoH/DoT 攔截、完整 IPv6 extension header、正式簽署與真機驗證。
