plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "tw.ytshield"
    compileSdk = 35
    defaultConfig {
        applicationId = "tw.ytshield"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "0.5.0"
    }
}


dependencies {
    implementation("androidx.work:work-runtime-ktx:2.10.0")
}
