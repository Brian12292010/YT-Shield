package tw.ytshield

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.app.AlertDialog
import android.net.VpnService
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.Locale
import kotlin.concurrent.thread
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var stats: TextView
    private lateinit var allowInput: EditText
    private lateinit var bypassInput: EditText
    private lateinit var rulesInfo: TextView
    private val requestCode = 7001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(24, 30, 24, 24)
            setBackgroundColor(Color.rgb(10, 16, 32))
        }
        fun label(text: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) =
            TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(color)
                gravity = Gravity.CENTER
                if (bold) typeface = Typeface.DEFAULT_BOLD
                setPadding(0, 7, 0, 7)
            }
        fun section(text: String) {
            layout.addView(label(text, 15f, Color.WHITE, true))
        }
        layout.addView(label("YT SHIELD", 30f, Color.WHITE, true))
        layout.addView(label("全系統廣告與追蹤網域過濾", 14f, Color.LTGRAY))
        status = label("防護狀態：尚未啟動", 18f)
        layout.addView(status)
        stats = label("", 13f, Color.LTGRAY)
        layout.addView(stats)

        layout.addView(Button(this).apply {
            text = "啟動全系統防護"
            setOnClickListener {
                saveSettings()
                val prepare = VpnService.prepare(this@MainActivity)
                if (prepare != null) startActivityForResult(prepare, requestCode) else startFilter()
            }
        }, LinearLayout.LayoutParams(-1, -2))
        layout.addView(Button(this).apply {
            text = "停止防護"
            setOnClickListener {
                stopService(Intent(this@MainActivity, DnsFilterVpnService::class.java))
                status.text = "防護狀態：已停止"
            }
        }, LinearLayout.LayoutParams(-1, -2))

        section("廣告過濾規則")
        rulesInfo = label(ruleInfoText(), 12f, Color.LTGRAY)
        layout.addView(rulesInfo)
        layout.addView(Button(this).apply {
            text = "立即更新廣告封鎖清單"
            setOnClickListener { updateRules() }
        }, LinearLayout.LayoutParams(-1, -2))

        section("白名單（每行一個網域）")
        allowInput = EditText(this).apply {
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            hint = "example.com"; minLines = 2
            setPadding(12, 8, 12, 8)
            setBackgroundColor(Color.rgb(28, 38, 58))
        }
        layout.addView(allowInput, LinearLayout.LayoutParams(-1, -2))

        section("不經過過濾的 App（每行一個套件名稱）")
        bypassInput = EditText(this).apply {
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            hint = "例如：com.example.app"; minLines = 2
            setPadding(12, 8, 12, 8)
            setBackgroundColor(Color.rgb(28, 38, 58))
        }
        layout.addView(bypassInput, LinearLayout.LayoutParams(-1, -2))
        layout.addView(Button(this).apply {
            text = "從已安裝 App 中選擇例外"
            setOnClickListener { showInstalledAppPicker() }
        }, LinearLayout.LayoutParams(-1, -2))

        layout.addView(Button(this).apply {
            text = "儲存設定"
            setOnClickListener { saveSettings(); Toast.makeText(this@MainActivity, "設定已儲存；重新啟動防護後套用 App 例外", Toast.LENGTH_LONG).show() }
        }, LinearLayout.LayoutParams(-1, -2))
        layout.addView(Button(this).apply {
            text = "更新攔截統計"
            setOnClickListener { refreshStats() }
        }, LinearLayout.LayoutParams(-1, -2))

        layout.addView(label(
            "重要：DNS 過濾只能攔截可辨識的廣告網域。YouTube 影片與廣告可能共用網域，無法保證移除所有影片廣告。此 App 不解密 HTTPS。",
            12f, Color.LTGRAY
        ))
        setContentView(layout)
        scheduleAutomaticRuleUpdates()
        loadSettings()
        refreshStats()
    }

    private fun startFilter() {
        startForegroundService(Intent(this, DnsFilterVpnService::class.java))
        status.text = "防護狀態：啟動要求已送出"
    }


    private fun showInstalledAppPicker() {
        val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val pm = packageManager
        val activities = if (android.os.Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(launcherIntent, PackageManager.ResolveInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(launcherIntent, 0)
        }
        val apps = activities.mapNotNull { info ->
            val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
            if (pkg == packageName) return@mapNotNull null
            val label = info.loadLabel(pm)?.toString()?.takeIf { it.isNotBlank() } ?: pkg
            pkg to "$label  ($pkg)"
        }.distinctBy { it.first }.sortedBy { it.second.lowercase(Locale.getDefault()) }

        if (apps.isEmpty()) {
            Toast.makeText(this, "找不到可選擇的已安裝 App", Toast.LENGTH_LONG).show()
            return
        }
        val selected = (getSharedPreferences("ytshield", MODE_PRIVATE)
            .getStringSet("bypass_packages", emptySet()) ?: emptySet()).toMutableSet()
        val labels = apps.map { it.second }.toTypedArray()
        val checked = BooleanArray(apps.size) { apps[it].first in selected }
        AlertDialog.Builder(this)
            .setTitle("選擇不經過 YT Shield 的 App")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked ->
                if (isChecked) selected.add(apps[which].first) else selected.remove(apps[which].first)
            }
            .setNegativeButton("取消", null)
            .setPositiveButton("套用") { _, _ ->
                bypassInput.setText(selected.sorted().joinToString("\n"))
                saveSettings()
                Toast.makeText(this, "已選取 ${selected.size} 個 App；重新啟動防護後生效", Toast.LENGTH_LONG).show()
            }
            .show()
    }

    private fun saveSettings() {
        val prefs = getSharedPreferences("ytshield", MODE_PRIVATE)
        val domains = allowInput.text.toString().lines()
            .map { it.trim().lowercase(Locale.US).trim('.') }
            .filter { it.matches(Regex("[a-z0-9-]+(\\.[a-z0-9-]+)+")) }
            .toSet()
        val packages = bypassInput.text.toString().lines()
            .map { it.trim() }
            .filter { it.matches(Regex("[A-Za-z0-9_]+(\\.[A-Za-z0-9_]+)+")) }
            .toSet()
        prefs.edit().putStringSet("allow_domains", domains)
            .putStringSet("bypass_packages", packages).apply()
    }

    private fun loadSettings() {
        val prefs = getSharedPreferences("ytshield", MODE_PRIVATE)
        allowInput.setText((prefs.getStringSet("allow_domains", emptySet()) ?: emptySet()).joinToString("\n"))
        bypassInput.setText((prefs.getStringSet("bypass_packages", emptySet()) ?: emptySet()).joinToString("\n"))
    }

    private fun refreshStats() {
        val prefs = getSharedPreferences("ytshield", MODE_PRIVATE)
        stats.text = "攔截 DNS：${prefs.getLong("blocked_count", 0L)}    正常放行：${prefs.getLong("passed_count", 0L)}"
        rulesInfo.text = ruleInfoText()
    }

    private fun ruleInfoText(): String {
        val prefs = getSharedPreferences("ytshield", MODE_PRIVATE)
        val count = prefs.getInt("remote_rule_count", 0)
        val updated = prefs.getLong("rules_updated_at", 0L)
        val date = if (updated == 0L) "尚未更新" else java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(java.util.Date(updated))
        return "遠端規則：$count 個網域｜最後更新：$date"
    }

    private fun scheduleAutomaticRuleUpdates() {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()
        val request = PeriodicWorkRequestBuilder<RuleUpdateWorker>(24, TimeUnit.HOURS)
            .setConstraints(constraints)
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "ytshield_daily_rule_update",
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }

    private fun updateRules() {
        status.text = "防護狀態：正在下載規則…"
        thread(name = "YTShield-RuleUpdate") {
            val result = RuleListUpdater.update(this)
            runOnUiThread {
                if (result.isSuccess) {
                    status.text = "防護狀態：規則更新完成"
                    refreshStats()
                    Toast.makeText(this, "已更新 ${result.getOrNull()} 個網域規則", Toast.LENGTH_LONG).show()
                } else {
                    status.text = "防護狀態：規則更新失敗"
                    Toast.makeText(this, "更新失敗，保留舊規則：${result.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::stats.isInitialized) refreshStats()
    }

    @Deprecated("Deprecated in Android API")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == this.requestCode && resultCode == RESULT_OK) startFilter()
    }
}
