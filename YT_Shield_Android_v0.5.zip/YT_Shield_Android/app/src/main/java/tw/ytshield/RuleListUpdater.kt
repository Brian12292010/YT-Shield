package tw.ytshield

import android.content.Context
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

/** Downloads and validates a hosts list before atomically replacing the local copy. */
object RuleListUpdater {
    private const val SOURCE = "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts"
    private const val MAX_DOMAINS = 40000
    private const val MIN_DOMAINS = 1000

    fun update(context: Context): Result<Int> {
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(SOURCE).openConnection() as HttpURLConnection).apply {
                connectTimeout = 12000
                readTimeout = 25000
                requestMethod = "GET"
                setRequestProperty("User-Agent", "YTShield-Android/0.4")
            }
            if (connection.responseCode != HttpURLConnection.HTTP_OK) {
                error("HTTP ${connection.responseCode}")
            }
            val domains = linkedSetOf<String>()
            connection.inputStream.bufferedReader().useLines { lines ->
                lines.forEach { line ->
                    val clean = line.substringBefore('#').trim()
                    val parts = clean.split(Regex("\\s+")).filter { it.isNotBlank() }
                    if (parts.size >= 2 && (parts[0] == "0.0.0.0" || parts[0] == "127.0.0.1" || parts[0] == "::1")) {
                        val domain = parts[1].lowercase(Locale.US).trimEnd('.')
                        if (domain.contains('.') && domain.length <= 253 &&
                            !domain.startsWith("localhost") && isValidDomain(domain) && domains.size < MAX_DOMAINS) {
                            domains.add(domain)
                        }
                    }
                }
            }
            require(domains.size >= MIN_DOMAINS) { "下載清單不完整（${domains.size} 個網域），舊清單已保留" }
            val prefs = context.getSharedPreferences("ytshield", Context.MODE_PRIVATE)
            val saved = prefs.edit()
                .putStringSet("remote_blocked_domains", domains)
                .putInt("remote_rule_count", domains.size)
                .putLong("rules_updated_at", System.currentTimeMillis())
                .commit()
            check(saved) { "無法儲存規則" }
            Result.success(domains.size)
        } catch (e: Exception) {
            Result.failure(e)
        } finally {
            connection?.disconnect()
        }
    }

    private fun isValidDomain(domain: String): Boolean {
        if (domain.length > 253 || domain.startsWith('.') || domain.endsWith('.')) return false
        return domain.split('.').all { label ->
            label.isNotEmpty() && label.length <= 63 &&
                label.first().isLetterOrDigit() && label.last().isLetterOrDigit() &&
                label.all { it.isLetterOrDigit() || it == '-' }
        }
    }
}
