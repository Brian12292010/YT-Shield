package tw.ytshield

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.Locale
import kotlin.concurrent.thread

/**
 * DNS-only local VPN prototype. Handles plain IPv4/IPv6 UDP DNS packets.
 * It does not inspect HTTPS traffic or decrypt TLS.
 */
class DnsFilterVpnService : VpnService() {
    @Volatile private var running = false
    private var tun: ParcelFileDescriptor? = null

    @Volatile private var remoteBlocked: Set<String> = emptySet()

    private val blocked = setOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "pagead2.googlesyndication.com",
        "adnxs.com", "adsystem.com", "adform.net", "taboola.com",
        "outbrain.com", "scorecardresearch.com", "app-measurement.com"
    )

    private fun activeBlockedDomains(): Set<String> = blocked + remoteBlocked

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createNotification()
        if (!running) startTunnel()
        return START_STICKY
    }

    private fun createNotification() {
        val id = "ytshield_vpn"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(id, "YT Shield 防護", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, id)
                      else Notification.Builder(this)
        builder.setContentTitle("YT Shield 正在運作")
            .setContentText("本機 DNS 過濾已啟動")
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setOngoing(true)
        startForeground(77, builder.build())
    }

    private fun startTunnel() {
        val pfdBuilder = Builder()
            .setSession("YT Shield DNS Filter")
            .addAddress("10.111.0.1", 32)
            .addDnsServer("10.111.0.2")
            .addRoute("10.111.0.2", 32)
            .addAddress("fd11:1111:1111::1", 128)
            .addDnsServer("fd11:1111:1111::2")
            .addRoute("fd11:1111:1111::2", 128)
            .setMtu(1500)
        val bypass = getSharedPreferences("ytshield", MODE_PRIVATE)
            .getStringSet("bypass_packages", emptySet()) ?: emptySet()
        try {
            bypass.forEach { packageName ->
                try { pfdBuilder.addDisallowedApplication(packageName) } catch (_: Exception) { }
            }
        } catch (_: Exception) { }
        val pfd = pfdBuilder.establish() ?: run { stopSelf(); return }
        tun = pfd
        remoteBlocked = getSharedPreferences("ytshield", MODE_PRIVATE)
            .getStringSet("remote_blocked_domains", emptySet()) ?: emptySet()
        running = true
        thread(name = "YTShield-DNS") { packetLoop(pfd) }
    }

    private data class Packet(
        val bytes: ByteArray,
        val version: Int,
        val ipHeader: Int,
        val dnsOffset: Int,
        val srcIp: ByteArray,
        val dstIp: ByteArray,
        val srcPort: Int,
        val dstPort: Int
    )

    private fun packetLoop(pfd: ParcelFileDescriptor) {
        val input = FileInputStream(pfd.fileDescriptor)
        val output = FileOutputStream(pfd.fileDescriptor)
        val buf = ByteArray(32767)
        while (running) {
            try {
                val n = input.read(buf)
                if (n <= 0) continue
                val packetBytes = buf.copyOf(n)
                val parsed = parseDnsPacket(packetBytes) ?: continue
                val name = readQName(parsed.bytes, parsed.dnsOffset)?.lowercase(Locale.US) ?: continue
                val prefs = getSharedPreferences("ytshield", MODE_PRIVATE)
                val allow = prefs.getStringSet("allow_domains", emptySet()) ?: emptySet()
                val allowed = allow.any {
                    val d = it.trim().lowercase(Locale.US)
                    d.isNotEmpty() && (name == d || name.endsWith(".$d"))
                }
                // Read the latest list so a background/manual update takes effect without restarting VPN.
                remoteBlocked = prefs.getStringSet("remote_blocked_domains", emptySet()) ?: emptySet()
                val shouldBlock = !allowed && activeBlockedDomains().any {
                    name == it || name.endsWith(".$it")
                }

                val dnsResponse = try {
                    if (shouldBlock) {
                        prefs.edit().putLong("blocked_count", prefs.getLong("blocked_count", 0L) + 1L).apply()
                        makeNxDomain(parsed.bytes, parsed.dnsOffset)
                    } else {
                        prefs.edit().putLong("passed_count", prefs.getLong("passed_count", 0L) + 1L).apply()
                        forwardDns(parsed.bytes.copyOfRange(parsed.dnsOffset, parsed.bytes.size))
                    }
                } catch (_: Exception) {
                    makeServFail(parsed.bytes, parsed.dnsOffset)
                }

                output.write(buildResponse(parsed, dnsResponse))
            } catch (_: Exception) {
                if (!running) break
            }
        }
    }

    private fun parseDnsPacket(p: ByteArray): Packet? {
        if (p.isEmpty()) return null
        return when ((p[0].toInt() ushr 4) and 0xF) {
            4 -> {
                if (p.size < 28 || (p[9].toInt() and 0xFF) != 17) return null
                val ihl = (p[0].toInt() and 0xF) * 4
                if (ihl < 20 || p.size < ihl + 8) return null
                val dst = p.copyOfRange(16, 20)
                if (!dst.contentEquals(byteArrayOf(10, 111, 0, 2))) return null
                val udpLen = u16(p, ihl + 4)
                if (udpLen < 20 || p.size < ihl + udpLen) return null
                val srcPort = u16(p, ihl)
                val dstPort = u16(p, ihl + 2)
                if (dstPort != 53) return null
                Packet(p, 4, ihl, ihl + 8, p.copyOfRange(12, 16), dst, srcPort, dstPort)
            }
            6 -> {
                if (p.size < 48 || (p[6].toInt() and 0xFF) != 17) return null // no extension headers in this MVP
                val dst = p.copyOfRange(24, 40)
                val expected = InetAddress.getByName("fd11:1111:1111::2").address
                if (!dst.contentEquals(expected)) return null
                val udpLen = u16(p, 44)
                if (udpLen < 20 || p.size < 40 + udpLen) return null
                val srcPort = u16(p, 40)
                val dstPort = u16(p, 42)
                if (dstPort != 53) return null
                Packet(p, 6, 40, 48, p.copyOfRange(8, 24), dst, srcPort, dstPort)
            }
            else -> null
        }
    }

    private fun readQName(d: ByteArray, off: Int): String? {
        if (d.size < off + 13) return null
        var i = off + 12
        val labels = mutableListOf<String>()
        while (i < d.size) {
            val len = d[i++].toInt() and 0xFF
            if (len == 0) break
            if ((len and 0xC0) != 0 || len > 63 || i + len > d.size) return null
            labels.add(String(d, i, len, Charsets.US_ASCII))
            i += len
        }
        return if (labels.isEmpty()) null else labels.joinToString(".")
    }

    private fun makeNxDomain(packet: ByteArray, offset: Int): ByteArray =
        makeErrorResponse(packet, offset, 3)

    private fun makeServFail(packet: ByteArray, offset: Int): ByteArray =
        makeErrorResponse(packet, offset, 2)

    private fun makeErrorResponse(packet: ByteArray, offset: Int, rcode: Int): ByteArray {
        val q = packet.copyOfRange(offset, packet.size)
        if (q.size < 12) return q
        q[2] = ((q[2].toInt() and 1) or 0x80).toByte()
        q[3] = ((q[3].toInt() and 0x70) or rcode).toByte()
        q[6] = 0; q[7] = 0; q[8] = 0; q[9] = 0; q[10] = 0; q[11] = 0
        return q
    }

    private fun forwardDns(query: ByteArray): ByteArray {
        require(query.size >= 12) { "DNS query too short" }
        val resolvers = listOf("1.1.1.1", "8.8.8.8")
        var lastError: Exception? = null
        for (resolver in resolvers) {
            val socket = DatagramSocket()
            try {
                if (!protect(socket)) throw IllegalStateException("VPN socket protection failed")
                socket.soTimeout = 2500
                val server = InetAddress.getByName(resolver)
                socket.send(DatagramPacket(query, query.size, server, 53))
                val data = ByteArray(4096)
                val response = DatagramPacket(data, data.size)
                socket.receive(response)
                if (response.length < 12) throw IllegalStateException("Invalid DNS response")
                // Accept only a DNS response matching the transaction ID of this query.
                if (data[0] != query[0] || data[1] != query[1] || (data[2].toInt() and 0x80) == 0) {
                    throw IllegalStateException("Mismatched DNS response")
                }
                return data.copyOf(response.length)
            } catch (e: Exception) {
                lastError = e
            } finally {
                socket.close()
            }
        }
        throw lastError ?: IllegalStateException("All DNS resolvers failed")
    }

    private fun buildResponse(request: Packet, dns: ByteArray): ByteArray {
        val ihl = request.ipHeader
        val out = ByteArray(ihl + 8 + dns.size)
        request.bytes.copyInto(out, 0, 0, ihl + 8)
        request.dstIp.copyInto(out, if (request.version == 4) 12 else 8)
        request.srcIp.copyInto(out, if (request.version == 4) 16 else 24)
        put16(out, ihl, request.dstPort)
        put16(out, ihl + 2, request.srcPort)
        put16(out, ihl + 4, 8 + dns.size)
        out[ihl + 6] = 0
        out[ihl + 7] = 0
        dns.copyInto(out, ihl + 8)

        if (request.version == 4) {
            put16(out, 2, out.size)
            out[10] = 0; out[11] = 0
            put16(out, 10, checksum(out, 0, ihl))
            // A zero UDP checksum is legal for IPv4.
        } else {
            put16(out, 4, out.size - 40)
            put16(out, ihl + 6, ipv6UdpChecksum(out, dns.size))
        }
        return out
    }

    private fun ipv6UdpChecksum(packet: ByteArray, dnsSize: Int): Int {
        val udpLength = 8 + dnsSize
        var sum = 0L
        fun addBytes(bytes: ByteArray, start: Int, length: Int) {
            var i = start
            while (i + 1 < start + length) {
                sum += (((bytes[i].toInt() and 255) shl 8) or (bytes[i + 1].toInt() and 255)).toLong()
                i += 2
            }
            if (i < start + length) sum += ((bytes[i].toInt() and 255) shl 8).toLong()
        }
        addBytes(packet, 8, 32) // IPv6 source and destination addresses
        sum += ((udpLength shr 16) and 0xffff).toLong()
        sum += (udpLength and 0xffff).toLong()
        sum += 17L // next-header UDP
        addBytes(packet, 40, udpLength)
        while ((sum shr 16) != 0L) sum = (sum and 0xffff) + (sum shr 16)
        val result = sum.inv().toInt() and 0xffff
        return if (result == 0) 0xffff else result
    }

    private fun checksum(b: ByteArray, start: Int, len: Int): Int {
        var sum = 0L
        var i = start
        while (i + 1 < start + len) {
            sum += (((b[i].toInt() and 255) shl 8) or (b[i + 1].toInt() and 255)).toLong()
            i += 2
        }
        if (i < start + len) sum += ((b[i].toInt() and 255) shl 8).toLong()
        while ((sum shr 16) != 0L) sum = (sum and 0xffff) + (sum shr 16)
        return sum.inv().toInt() and 0xffff
    }

    private fun u16(b: ByteArray, i: Int) =
        ((b[i].toInt() and 255) shl 8) or (b[i + 1].toInt() and 255)

    private fun put16(b: ByteArray, i: Int, v: Int) {
        b[i] = (v shr 8).toByte()
        b[i + 1] = v.toByte()
    }

    override fun onRevoke() {
        stopTunnel()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopTunnel()
        super.onDestroy()
    }

    private fun stopTunnel() {
        running = false
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        stopForeground(STOP_FOREGROUND_REMOVE)
    }
}
