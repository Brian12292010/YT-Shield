package tw.ytshield

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters

class RuleUpdateWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        val result = RuleListUpdater.update(applicationContext)
        return if (result.isSuccess) Result.success() else Result.retry()
    }
}
